#!/usr/bin/env python3
"""Rebuild AgentPet pixel art: every frame is an independent complete pose.
Requires Pillow and NumPy. No image-generation service or external resources.
"""
from __future__ import annotations
import json, math, random, io
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent
S = 48
SIZE = 96
FPS = 8
TIERS = ['fresh','focused','tired','exhausted','empty']
RANGES = {'fresh':[75,100], 'focused':[45,74], 'tired':[20,44], 'exhausted':[1,19], 'empty':[0,0]}
STATES = [
 'idle','typing','thinking','needs_input','ready','celebrating','failed','interrupted',
 'paused','unknown','disconnected','reconnecting','syncing','sleeping','walking','hovering',
 'low_quota','critical_quota','stretching','yawning','coffee_break','looking_around',
 'tiny_dance','cap_adjust','booped','giggling','annoyed','grabbed','dragging','landing']
EDGES = [
 ('start_work','idle','typing'),('think','typing','thinking'),('resume_typing','thinking','typing'),
 ('request_input','typing','needs_input'),('approve','needs_input','typing'),('finish','typing','ready'),
 ('celebrate','ready','celebrating'),('settle','celebrating','idle'),('fail','typing','failed'),
 ('interrupt','typing','interrupted'),('pause','typing','paused'),('unpause','paused','typing'),
 ('disconnect','typing','disconnected'),('reconnect','disconnected','reconnecting'),
 ('connected','reconnecting','idle'),('begin_sync','idle','syncing'),('end_sync','syncing','idle'),
 ('sleep','idle','sleeping'),('wake','sleeping','idle'),('quota_low','idle','low_quota'),
 ('quota_critical','low_quota','critical_quota'),('stretch','idle','stretching'),
 ('stretch_finish','stretching','idle'),('yawn','idle','yawning'),
 ('caffeinate','idle','coffee_break'),('look','idle','looking_around'),
 ('dance','idle','tiny_dance'),('adjust_cap','idle','cap_adjust'),
 ('hover','idle','hovering'),('hover_end','hovering','idle'),('click','idle','booped'),
 ('click_end','booped','idle'),('double_click','booped','giggling'),('annoy','booped','annoyed'),
 ('pickup','idle','grabbed'),('drag','grabbed','dragging'),
 ('drop','dragging','landing'),('drop_end','landing','idle')
]
assert len(STATES)==30 and len(EDGES)==38
LOOP = {'idle','typing','thinking','needs_input','ready','failed','interrupted','paused',
        'unknown','disconnected','reconnecting','syncing','sleeping','walking','hovering',
        'low_quota','critical_quota','dragging'}
STATE_FPS={'idle':5,'typing':11,'thinking':5,'needs_input':6,'ready':7,'celebrating':10,
           'sleeping':3,'walking':9,'hovering':6,'stretching':8,'yawning':5,
           'tiny_dance':10,'cap_adjust':7,'dragging':9,'booped':9,'giggling':8,'annoyed':6,
           'landing':10}
OUT=(66,47,65,255)
OUT_SOFT=(100,68,78,255)
WHITE=(255,250,229,255)
SHELL_SHADOW=(184,201,199,255)
SHELL_INNER=(239,234,218,255)
TEAL=(70,153,151,255)
TEAL_DARK=(54,105,117,255)
TEAL_LIGHT=(139,221,197,255)
PINK=(246,132,135,255)
ORANGE=(231,131,76,255)
YELLOWS=[(255,212,104,255),(252,205,112,255),(238,192,119,255),
         (225,180,123,255),(212,169,126,255)]
HIGHLIGHTS=[(255,237,154,255),(255,229,151,255),(247,215,159,255),
            (234,202,156,255),(220,187,150,255)]
SHADOWS=[(229,164,79,255),(223,160,87,255),(205,150,98,255),
          (185,132,104,255),(165,115,108,255)]

# Wing tip descriptors are coordinates relative to a complete pose: 1 single wing per side.
TIP={
 'rest':((8,29),(40,29)), 'out':((5,25),(43,25)),
 'high':((5,15),(43,15)), 'sky':((8,11),(40,11)),
 'half':((7,20),(41,20)), 'typing0':((18,34),(33,29)),
 'typing1':((14,29),(30,34)), 'chin':((17,24),(41,29)),
 'rightup':((9,30),(38,14)), 'leftup':((9,16),(39,30)),
 'fold':((16,34),(32,34)), 'grab':((6,19),(42,19)),
 'dance0':((8,18),(41,27)), 'dance1':((8,27),(40,18)),
 'mug':((9,31),(37,25)), 'phone':((10,29),(36,27))}


def clamp(v,lo,hi): return max(lo,min(hi,v))

def mix(a,b,t): return a*(1-t)+b*t

def ease(t): return t*t*(3-2*t)

def pose(name: str, phase:float, tier_i:int):
    p={'name':name,'l':'rest','r':'rest','lift':0.,'squash':0.,'lean':0.,
       'blink':False,'mouth':'smile','eyes':'normal','prop':'none',
       'effect':None,'shake':0.,'cap':0.,'foot':0.,'looking':0.}
    cyc=math.sin(phase*math.tau)
    p['lift']=0.40*cyc
    if name=='idle':
        p['lift']=.38*cyc;p['blink']=phase>.84 and phase<.94;p['l']='rest';p['r']='rest';
        p['cap']=.12*cyc
    elif name=='typing':
        p.update(l='typing0' if phase<.5 else 'typing1',r='typing0' if phase<.5 else 'typing1',
                 lift=.6*cyc,prop='laptop',mouth='focus',effect='type')
    elif name=='thinking':
        p.update(l='chin',r='chin',prop='laptop',eyes='side',mouth='dot',effect='thought',lean=0.5*cyc)
    elif name=='needs_input':
        p.update(l='rightup',r='rightup',eyes='wide',mouth='o',effect='bang',lift=.65*cyc)
    elif name=='ready':
        p.update(l='half',r='half',mouth='smile',effect='check',lift=.55*cyc)
    elif name=='celebrating':
        p.update(l='high' if phase<.5 else 'out',r='high' if phase<.5 else 'out',
                 lift=-1.7*abs(cyc),mouth='laugh',eyes='happy',effect='confetti')
    elif name=='failed':
        p.update(l='fold',r='fold',mouth='frown',eyes='sad',effect='error',prop='laptop')
    elif name=='interrupted':
        p.update(l='out',r='out',eyes='wide',mouth='o',effect='stop')
    elif name=='paused':
        p.update(l='rest',r='rest',eyes='half',effect='pause',lift=0)
    elif name=='unknown':
        p.update(l='out',r='out',mouth='dot',eyes='side',effect='question')
    elif name=='disconnected':
        p.update(l='fold',r='fold',eyes='sad',mouth='frown',effect='disconnect',lift=.1*cyc)
    elif name=='reconnecting':
        p.update(l='half',r='half',eyes='side',effect='reconnect',lift=.15*cyc)
    elif name=='syncing':
        p.update(l='typing0',r='typing0',prop='laptop',effect='sync',lift=.3*cyc)
    elif name=='sleeping':
        p.update(l='fold',r='fold',eyes='sleep',mouth='dot',effect='sleep',lift=.1*cyc)
    elif name=='walking':
        p.update(l='rest',r='rest',foot=cyc,lean=1.0*cyc,lift=-.6*abs(cyc))
    elif name=='hovering':
        p.update(l='half',r='half',eyes='wide',mouth='smile',effect='sparkle',lift=-.4*abs(cyc))
    elif name=='low_quota':
        p.update(l='fold',r='fold',eyes='half',mouth='dot',effect='sweat')
    elif name=='critical_quota':
        p.update(l='fold',r='fold',eyes='sad',mouth='frown',effect='sweat2',lean=1.0*cyc)
    elif name=='stretching':
        amplitude=max(0,math.sin(math.pi*phase))**1.6
        p.update(l='high' if amplitude>.48 else 'half',r='high' if amplitude>.48 else 'half',
                 mouth='o' if amplitude>.5 else 'smile',lift=-1.2*amplitude,
                 squash=-.8*amplitude,eyes='happy')
        p['lxy']=(mix(8,5,amplitude),mix(29,15,amplitude))
        p['rxy']=(mix(40,43,amplitude),mix(29,15,amplitude))
    elif name=='yawning':
        p.update(l='chin',r='chin',mouth='open' if .2<phase<.83 else 'dot',eyes='sleep',
                 effect='yawn' if .2<phase<.83 else None)
    elif name=='coffee_break':
        p.update(l='mug',r='mug',eyes='happy',mouth='smile',prop='mug',effect='steam')
    elif name=='looking_around':
        p.update(l='phone',r='phone',eyes='side',mouth='dot',prop='phone',looking=cyc*2)
    elif name=='tiny_dance':
        p.update(l='dance0' if phase<.5 else 'dance1',r='dance0' if phase<.5 else 'dance1',
                 lift=-1.5*abs(cyc),lean=1.1*cyc,eyes='happy',mouth='laugh',effect='notes')
    elif name=='cap_adjust':
        p.update(l='rightup',r='rightup',eyes='side',mouth='smile',cap=-2*math.sin(math.pi*phase),effect='sparkle')
        lift_cap=max(0,math.sin(math.pi*phase))
        p['rxy']=(mix(40,32,lift_cap),mix(29,13,lift_cap))
    elif name=='booped':
        p.update(l='out',r='out',squash=1.6*math.sin(math.pi*phase),eyes='squint',mouth='o',effect='boop')
    elif name=='giggling':
        p.update(l='half',r='half',shake=.75*cyc,eyes='happy',mouth='laugh',effect='hearts')
    elif name=='annoyed':
        p.update(l='fold',r='fold',eyes='angry',mouth='frown',effect='angry',shake=.4*cyc)
    elif name=='grabbed':
        p.update(l='grab',r='grab',lift=-1,eyes='wide',mouth='o',foot=.5,effect='grab')
    elif name=='dragging':
        p.update(l='grab',r='grab',lift=-1.5,lean=1.2*cyc,foot=cyc,eyes='wide',mouth='o',effect='drag')
    elif name=='landing':
        p.update(l='out',r='out',squash=2.0*math.sin(math.pi*phase),lift=1.2*math.sin(math.pi*phase),
                 eyes='squint',mouth='o',effect='dust')
    # Physical fatigue: body stoops, cap tilts, wings lower, feet shuffle,
    # independent per pose (not a tinting pass on a fixed frame).
    p['fatigue']=tier_i
    if tier_i >= 2:
        p['lift'] += (tier_i-1)*.5
        p['squash'] += (tier_i-1)*.45
        p['lean'] += .35*(tier_i-1)
        if p['eyes'] in ('normal','side'): p['eyes']='half' if tier_i==2 else 'tired'
        if name in ('idle','typing','thinking','walking') and tier_i>=3: p['mouth']='dot'
    if tier_i==4:
        p['lift']+=.5
        p['squash']+=.65
        if p['eyes'] not in ('wide','happy','angry'): p['eyes']='sleepy'
    if 'lxy' not in p: p['lxy']=TIP.get(p['l'],TIP['rest'])[0]
    if 'rxy' not in p: p['rxy']=TIP.get(p['r'],TIP['rest'])[1]
    return p


def between(a,b,t):
    p={}; t=ease(t)
    for k in a:
        if k in ('lift','squash','lean','shake','cap','foot','looking'):
            p[k]=mix(a[k],b[k],t)
        elif k in ('lxy','rxy'):
            p[k]=(mix(a[k][0],b[k][0],t),mix(a[k][1],b[k][1],t))
        elif k=='fatigue': p[k]=a[k]
        elif k=='name': p[k]=a[k] if t<.5 else b[k]
        else: p[k]=a[k] if t<.5 else b[k]
    p['transition']=True
    return p


def quad(draw,xy,fill): draw.polygon([(int(round(x)),int(round(y))) for x,y in xy],fill=fill)

def rect(draw,xy,fill): draw.rectangle(tuple(int(round(v)) for v in xy),fill=fill)

def line(draw,pts,fill,width=1): draw.line([(int(round(x)),int(round(y))) for x,y in pts],fill=fill,width=width)


def draw_pose(p):
    """Produce entire self-contained sprite per call; never composite prebuilt limbs/body."""
    tier=p['fatigue']; img=Image.new('RGBA',(S,S),(0,0,0,0));d=ImageDraw.Draw(img)
    cx=24+p['shake']+p['lean']*.52
    fat=tier
    yoff=p['lift']+fat*.18
    flatten=p['squash']+fat*.30
    halfwidth=14 - .35*fat
    top=13 + yoff + flatten*.65
    bottom=40 + yoff - flatten*.25
    # Two orange feet, with phase-shifted stepping. Feet partly hidden beneath the body silhouette.
    left_step=-(max(0,p['foot']))*1.5
    right_step=-max(0,-p['foot'])*1.5
    feet=[(cx-7+fat*.12,bottom+1+left_step),(cx+6-fat*.12,bottom+1+right_step)]
    for fx,fy in feet:
        rect(d,(fx-2,fy-1,fx+2,fy+2),OUT)
        rect(d,(fx-1,fy-1,fx+1,fy+1),ORANGE)
        rect(d,(fx-3,fy+2,fx+2,fy+2),ORANGE)
    # UNIFIED body + EXACTLY TWO wings silhouette. Each wing geometry is freshly
    # derived from this frame's pose and unioned into one body mask before outlining.
    mask=Image.new('L',(S,S),0);m=ImageDraw.Draw(mask)
    m.ellipse((int(cx-halfwidth),int(top),int(cx+halfwidth),int(bottom)),fill=255)
    # Side wing tip coordinates within this same body canvas.
    lk,rk=p['l'],p['r']
    lt,rt=p['lxy'],p['rxy']
    def attached_wing(side,tip):
        sign=side
        sx=cx+sign*(halfwidth-3)
        sy=27+yoff + flatten*.18
        tx=tip[0]+p['lean']*.5+p['shake']
        ty=tip[1]+yoff*.5+fat*.35
        dx=tx-sx;dy=ty-sy
        dist=max(1,(dx*dx+dy*dy)**.5)
        nx=-dy/dist;ny=dx/dist
        # A broad tapered organic outline rather than detached oval appendage.
        thickness=3.4 if lk!='high' else 3.7
        vertices=[(sx-nx*3,sy-ny*3),
          (sx+dx*.55-nx*3.5,sy+dy*.55-ny*3.5),
          (tx-nx*2.8,ty-ny*2.8),
          (tx+dx/dist*.8,ty+dy/dist*.8),
          (tx+nx*3.4,ty+ny*3.4),
          (sx+dx*.55+nx*4,sy+dy*.55+ny*4),
          (sx+nx*3,sy+ny*3)]
        quad(m,vertices,255)
        m.ellipse((int(tx-2),int(ty-2),int(tx+2),int(ty+2)),fill=255)
        return (tx,ty)
    left_tip=attached_wing(-1,lt)
    right_tip=attached_wing(+1,rt)
    outline=mask.filter(ImageFilter.MaxFilter(3))
    img.paste(OUT,(0,0),outline)
    fillcolor=YELLOWS[tier]
    img.paste(fillcolor,(0,0),mask)
    # Each frame gets physically placed belly shading and highlights clipped to its silhouette.
    overlay=Image.new('RGBA',(S,S),(0,0,0,0));o=ImageDraw.Draw(overlay)
    o.ellipse((int(cx-halfwidth+3),int(top+2),int(cx+halfwidth-5),int(top+18)),fill=HIGHLIGHTS[tier])
    o.arc((int(cx-halfwidth+5),int(bottom-13),int(cx+halfwidth-5),int(bottom+2)),5,170,fill=SHADOWS[tier],width=3)
    o.ellipse((int(cx-9),int(bottom-10),int(cx+8),int(bottom)),fill=(*SHADOWS[tier][:3],115))
    img.alpha_composite(Image.composite(overlay,Image.new('RGBA',(S,S),(0,0,0,0)),mask))
    d=ImageDraw.Draw(img)
    # Subtle discrete feathers/wing crease; wing count never changes.
    for tip,side in [(left_tip,-1),(right_tip,1)]:
        sx=cx+side*(halfwidth-6); sy=29+yoff
        bx=mix(sx,tip[0],.54);by=mix(sy,tip[1],.54)
        line(d,[(bx-side,by-1),(bx+side*.4,by+1)],SHADOWS[tier],1)
    # Eggshell hat: smaller cap, scalloped/jagged egg crack edge, physically sits on head.
    capcx=cx+p['cap']*.35 + fat*.13
    capY=10+yoff+flatten*.45 + p['cap']*.2
    shell=[(capcx-9,capY+5),(capcx-8,capY+1),(capcx-6,capY-2),
           (capcx-3,capY-4),(capcx+3,capY-4),(capcx+7,capY-2),
           (capcx+9,capY+3),(capcx+8,capY+7),
           (capcx+5,capY+5),(capcx+3,capY+7),(capcx+1,capY+5),
           (capcx-2,capY+7),(capcx-4,capY+5),(capcx-7,capY+7),
           (capcx-9,capY+5)]
    quad(d,shell,OUT)
    inner=[(x*(.93)+capcx*.07,y-1) for x,y in shell]
    quad(d,inner,WHITE)
    line(d,[(capcx-7,capY+3),(capcx-5,capY-1),(capcx,capY-2)],(255,255,242,255),2)
    line(d,[(capcx+6,capY+1),(capcx+7,capY+4),(capcx+4,capY+4)],SHELL_SHADOW,1)
    # Very small cyan <> code pin, not clothing/headphones.
    for x,y in [(capcx-1,capY+1),(capcx+1,capY+1)]:d.point((int(x),int(y)),fill=TEAL_DARK)
    # Blushing cheeks under the eyes.
    face_y=26+yoff + flatten*.3
    eye_xl=cx-5+p['looking'];eye_xr=cx+5+p['looking']
    rect(d,(cx-11,face_y+3,cx-8,face_y+5),PINK)
    rect(d,(cx+8,face_y+3,cx+11,face_y+5),PINK)
    eye_mode=p['eyes']
    for ex in (eye_xl,eye_xr):
        ey=face_y-2+fat*.12
        if eye_mode in ('sleep','sleepy'):
            line(d,[(ex-2,ey+2),(ex,ey+3),(ex+2,ey+2)],OUT,1)
        elif eye_mode in ('happy','squint'):
            line(d,[(ex-2,ey+1),(ex,ey-1),(ex+2,ey+1)],OUT,1)
        elif eye_mode=='angry':
            line(d,[(ex-2,ey-2),(ex+2,ey-1 if ex<cx else ey-3)],OUT,1)
            rect(d,(ex-1,ey,ex+1,ey+1),OUT)
        elif eye_mode=='tired':
            rect(d,(ex-2,ey,ex+2,ey+1),OUT)
            rect(d,(ex-2,ey+2,ex+1,ey+2),SHADOWS[tier])
        elif eye_mode=='half':
            rect(d,(ex-2,ey,ex+2,ey),OUT)
            rect(d,(ex-1,ey+1,ex+1,ey+1),OUT)
        elif eye_mode=='sad':
            line(d,[(ex-2,ey-2),(ex+1,ey-1)],OUT,1)
            rect(d,(ex-1,ey,ex+1,ey+2),OUT)
        elif eye_mode=='wide':
            rect(d,(ex-2,ey-2,ex+2,ey+2),WHITE)
            rect(d,(ex,ey-1,ex+1,ey+2),OUT)
        else:
            if p['blink']:
                line(d,[(ex-2,ey+1),(ex+2,ey+1)],OUT)
            else:
                rect(d,(ex-1,ey-1,ex+1,ey+2),OUT)
                d.point((int(ex),int(ey-1)),fill=WHITE)
    # Strongly visible exhaustion changes, not merely recoloring.
    if tier>=2:
        for side in (-1,1):
            ex=cx+side*5
            line(d,[(ex-2,face_y+2),(ex+2,face_y+2)],SHADOWS[tier],1)
        if tier>=3:
            line(d,[(cx-9,face_y-7),(cx-6,face_y-8)],SHADOWS[tier],1)
            rect(d,(cx+11,face_y, cx+12,face_y+3),TEAL_LIGHT)
            d.point((int(cx+12),int(face_y+5)),fill=TEAL_LIGHT)
        if tier>=4:
            line(d,[(cx-3,face_y-7),(cx-1,face_y-8)],SHADOWS[tier])
            line(d,[(cx+1,face_y-8),(cx+3,face_y-7)],SHADOWS[tier])
    # Beak and mouth.
    mouth=p['mouth'];bx=cx;by=face_y+4
    if mouth in ('o','open'):
        d.ellipse((int(bx-2),int(by-1),int(bx+2),int(by+(4 if mouth=='open' else 2))),fill=OUT)
        rect(d,(bx-1,by,bx+1,by+1),ORANGE)
    elif mouth=='laugh':
        d.arc((int(bx-4),int(by-1),int(bx+4),int(by+3)),0,180,fill=OUT,width=2)
        rect(d,(bx-2,by+1,bx+2,by+2),ORANGE)
    elif mouth=='frown':
        d.arc((int(bx-3),int(by+1),int(bx+3),int(by+4)),185,355,fill=OUT,width=1)
    elif mouth in ('dot','focus'):
        rect(d,(bx-1,by,bx+1,by),ORANGE)
    else:
        quad(d,[(bx-3,by-1),(bx+3,by-1),(bx+1,by+2),(bx-1,by+2)],ORANGE)
        line(d,[(bx-2,by),(bx,by+1),(bx+2,by)],SHADOWS[tier],1)
    # Props are correctly attached/positioned, never free-standing extra hands.
    prop=p['prop']
    if prop=='laptop':
        by=int(round(35+yoff*.15))
        rect(d,(17,by-4,33,by+5),OUT)
        rect(d,(18,by-3,32,by+2),TEAL_DARK)
        rect(d,(19,by-2,31,by+1),TEAL)
        rect(d,(23,by-1,27,by),TEAL_LIGHT)
        # Code symbol on the cute mini laptop: <>.
        line(d,[(22,by),(23,by-1),(22,by-2)],WHITE)
        line(d,[(28,by-2),(27,by-1),(28,by)],WHITE)
        rect(d,(15,by+4,35,by+5),OUT)
        rect(d,(17,by+4,33,by+4),SHELL_SHADOW)
        rect(d,(24,by+5,27,by+5),TEAL_LIGHT)
        # Same two attached wings cross the mini laptop edge while typing.
        # They are drawn as continuous folds from existing body shoulders, not extra limbs.
        for side,(x,y) in [(-1,left_tip),(1,right_tip)]:
            sx=int(cx+side*11); sy=int(face_y+3)
            tx=int(clamp(x,11,38));ty=int(clamp(y,by-5,by+5))
            line(d,[(sx,sy),(sx+side*1,sy+4),(tx,ty)],OUT,width=3)
            line(d,[(sx,sy),(sx+side*1,sy+4),(tx,ty)],HIGHLIGHTS[tier],width=2)
    elif prop=='phone':
        x=int(cx+11);y=int(face_y+4)
        rect(d,(x,y-5,x+5,y+4),OUT)
        rect(d,(x+1,y-4,x+4,y+2),TEAL_DARK)
        rect(d,(x+2,y-2,x+3,y-2),TEAL_LIGHT)
        d.point((x+2,y+3),fill=WHITE)
    elif prop=='mug':
        x=int(cx+10);y=int(face_y+5)
        rect(d,(x,y-1,x+5,y+5),OUT)
        rect(d,(x+1,y,x+4,y+4),WHITE)
        rect(d,(x+5,y+1,x+6,y+3),OUT)
        rect(d,(x+2,y+1,x+3,y+1),ORANGE)
    # Tiny state effects: use only 1-3 marks, not a second limb.
    eff=p['effect'];q=math.sin(math.tau*(p.get('phase',0)))
    def sparkle(x,y):
        line(d,[(x-2,y),(x+2,y)],TEAL_LIGHT)
        line(d,[(x,y-2),(x,y+2)],TEAL_LIGHT)
    if eff=='type':
        x=37 if p.get('phase',0)<.5 else 10
        sparkle(x,33)
    elif eff=='thought':
        for xx,yy in [(37,14),(40,11),(43,9)]: d.ellipse((xx,yy,xx+2,yy+2),fill=TEAL_LIGHT)
    elif eff=='bang':
        rect(d,(40,15,41,20),ORANGE);rect(d,(40,22,41,23),ORANGE)
    elif eff=='check':
        line(d,[(38,20),(40,22),(44,17)],TEAL_DARK,2)
    elif eff=='confetti':
        for xx,yy,c in [(7,12,PINK),(39,13,TEAL),(43,24,ORANGE),(9,24,TEAL_LIGHT)]:
            rect(d,(xx,yy,xx+1,yy+1),c)
    elif eff=='error':
        line(d,[(39,14),(43,18)],PINK,2);line(d,[(43,14),(39,18)],PINK,2)
    elif eff=='stop':
        rect(d,(39,12,43,16),ORANGE)
    elif eff=='pause':
        rect(d,(41,16,42,21),TEAL_DARK);rect(d,(44,16,45,21),TEAL_DARK)
    elif eff=='question':
        d.arc((39,14,44,19),180,355,fill=TEAL_DARK,width=2);rect(d,(41,21,42,22),TEAL_DARK)
    elif eff=='disconnect':
        line(d,[(39,13),(44,18)],OUT);line(d,[(44,13),(39,18)],OUT)
    elif eff in ('reconnect','sync'):
        for xx,yy in [(41,13),(44,15),(42,18)]: d.point((xx,yy),fill=TEAL_DARK)
    elif eff=='sleep':
        for xx,yy in [(39,16),(42,12)]:
            line(d,[(xx,yy),(xx+3,yy),(xx,yy+3),(xx+3,yy+3)],TEAL_DARK)
    elif eff in ('sweat','sweat2'):
        rect(d,(39,21,40,24),TEAL_LIGHT)
    elif eff=='sparkle':sparkle(40,13)
    elif eff=='steam':
        line(d,[(37,26),(38,24),(37,22)],SHELL_SHADOW)
    elif eff=='yawn':
        line(d,[(41,18),(44,16)],SHELL_SHADOW,1)
    elif eff=='notes':
        rect(d,(40,16,41,20),TEAL_DARK);rect(d,(40,20,42,21),TEAL_DARK)
    elif eff=='boop':sparkle(40,25)
    elif eff=='hearts':
        rect(d,(39,13,42,15),PINK);rect(d,(40,16,41,17),PINK)
    elif eff=='angry':
        rect(d,(40,12,44,13),PINK);rect(d,(42,14,43,17),PINK)
    elif eff=='grab':
        line(d,[(8,13),(6,10)],ORANGE,1)
    elif eff=='drag':
        line(d,[(7,22),(5,25)],SHELL_SHADOW,2)
    elif eff=='dust':
        for x in (6,41):
            rect(d,(x,40,x+3,41),SHELL_SHADOW)
    return img.resize((SIZE,SIZE),Image.Resampling.NEAREST)


def render(name:str, fi:int, tier:int, edge=None):
    phase=fi/8
    if edge:
        a=pose(edge[1],phase,tier)
        b=pose(edge[2],phase,tier)
        p=between(a,b,(fi+.5)/8)
        if edge[0] in ('click','double_click','annoy'):
            p['effect']='boop' if fi<4 else b.get('effect')
    else:
        p=pose(name,phase,tier)
    p['phase']=phase
    return draw_pose(p)


def glyphs():
    FONT={
    '0':['111','101','101','101','111'],'1':['010','110','010','010','111'],
    '2':['111','001','111','100','111'],'3':['111','001','111','001','111'],
    '4':['101','101','111','001','001'],'5':['111','100','111','001','111'],
    '6':['111','100','111','101','111'],'7':['111','001','010','010','010'],
    '8':['111','101','111','101','111'],'9':['111','101','111','001','111']}
    strip=Image.new('RGBA',(40,5),(0,0,0,0));d=ImageDraw.Draw(strip)
    for i,key in enumerate('0123456789'):
        for y,row in enumerate(FONT[key]):
            for x,v in enumerate(row):
                if v=='1':d.point((i*4+x,y),fill=OUT)
    return strip


def make_hud():
    dpath=ROOT/'hud';dpath.mkdir(parents=True,exist_ok=True)
    # Two tiny standalone bars only: no frame, numbers, labels or background plate.
    panel=Image.new('RGBA',(36,14),(0,0,0,0));d=ImageDraw.Draw(panel)
    for y in (1,9):
        d.rectangle((2,y,33,y+3),fill=OUT)
        d.rectangle((3,y+1,32,y+2),fill=(126,140,145,230))
        d.point((3,y+1),fill=(158,179,182,255))
    panel.save(dpath/'bars.png')
    fills={'fill_green':TEAL_LIGHT,'fill_amber':(255,184,94,255),
           'fill_red':PINK,'fill_empty':(126,140,145,255)}
    for name,c in fills.items():
        im=Image.new('RGBA',(30,2),c);im.save(dpath/(name+'.png'))
    bubble=Image.new('RGBA',(20,19),(0,0,0,0));b=ImageDraw.Draw(bubble)
    # Separate little thought cloud, with lower-left small beads.
    b.ellipse((3,1,18,14),fill=OUT)
    b.ellipse((5,0,16,15),fill=OUT)
    b.ellipse((5,2,16,12),fill=WHITE)
    b.ellipse((8,14,10,16),fill=OUT)
    b.point((6,18),fill=OUT)
    bubble.save(dpath/'task_bubble.png')
    glyphs().save(dpath/'digits.png')
    return {'file':'hud/bars.png','size':[36,14],
            'positions':{'5H_bar':[2,1,32,4],'7D_bar':[2,9,32,4]},
            'fillInsets':[1,1], 'fillSize':[30,2],
            'showLabels':False,'showPercent':False,'showOuterPanel':False,
            'taskBubble':{'file':'hud/task_bubble.png','size':[20,19],
                           'showOnlyWhenRunningCountAbove':0,'numberPosition':[6,5]},
            'pixelFont':'hud/digits.png','pixelFontGlyphs':'0123456789',
            'dynamicValues':True}


def icons(frame):
    app=ROOT/'icons'/'AppIcon.appiconset';app.mkdir(parents=True,exist_ok=True)
    src=Image.new('RGBA',(96,96),(0,0,0,0));src.alpha_composite(frame)
    files=[]
    for pt in (16,32,128,256,512):
        for scale in (1,2):
            size=pt*scale
            fn=f'icon_{pt}x{pt}@{scale}x.png'
            src.resize((size,size),Image.Resampling.NEAREST).save(app/fn)
            files.append({'filename':fn,'idiom':'mac','size':f'{pt}x{pt}','scale':f'{scale}x'})
    (app/'Contents.json').write_text(json.dumps({'images':files,'info':{'author':'xcode','version':1}},indent=2))
    mb=ROOT/'icons'/'menubar';mb.mkdir(parents=True,exist_ok=True)
    for px in (18,36):
        canvas=Image.new('RGBA',(px,px),(0,0,0,0));dd=ImageDraw.Draw(canvas)
        # Monochrome eggshell and yolk silhouette suitable for NSImage.isTemplate.
        f=Image.new('RGBA',(24,24),(0,0,0,0));a=ImageDraw.Draw(f)
        a.ellipse((4,6,19,21),fill=(0,0,0,255))
        a.polygon([(7,9),(6,6),(8,3),(15,3),(18,6),(17,9),(14,8),(12,10),(10,8)],fill=(0,0,0,255))
        # Hollow eyes are transparent.
        a.rectangle((9,14,9,14),fill=(0,0,0,0));a.rectangle((14,14,14,14),fill=(0,0,0,0))
        canvas.alpha_composite(f.resize((px,px),Image.Resampling.NEAREST))
        canvas.save(mb/f'AgentPetTemplate-{px}.png')


def sheet(states,tier):
    im=Image.new('RGBA',(96*8,len(states)*96),(0,0,0,0))
    for idx,name in enumerate(states):
        edge=next((e for e in EDGES if e[0]==name),None)
        for f in range(8):im.alpha_composite(render(name,f,tier,edge=edge),((f%8)*96,idx*96))
    return im


def make_preview():
    prev=ROOT/'previews';prev.mkdir(exist_ok=True)
    # Helpful contact sheets with white/light backgrounds, clearly labeled.
    try:
        from PIL import ImageFont
        font=ImageFont.load_default()
    except Exception:font=None
    states=['idle','typing','thinking','needs_input','ready','celebrating','stretching','yawning',
            'coffee_break','looking_around','tiny_dance','cap_adjust','booped','giggling','annoyed',
            'grabbed','dragging','landing','sleeping','failed','critical_quota']
    cw,ch=180,190
    board=Image.new('RGB',(cw*5,ch*math.ceil(len(states)/5)),(243,246,241))
    d=ImageDraw.Draw(board)
    for i,name in enumerate(states):
        col=i%5;row=i//5; x=col*cw;y=row*ch
        frame=render(name,3,0).resize((160,160),Image.Resampling.NEAREST)
        board.paste(frame,(x+10,y+5),frame)
        d.text((x+7,y+165),name,fill=(65,47,65),font=font)
    board.save(prev/'states.png')
    energy=Image.new('RGB',(180*5,180*8),(244,245,241));e=ImageDraw.Draw(energy)
    selected=['idle','typing','needs_input','ready','stretching','cap_adjust','dragging','sleeping']
    for j,name in enumerate(selected):
        for tier in range(5):
            x=tier*180;y=j*180
            im=render(name,3,tier).resize((142,142),Image.Resampling.NEAREST)
            energy.paste(im,(x+18,y+3),im)
            e.text((x+8,y+149),name+' '+TIERS[tier],fill=(65,47,65))
    energy.save(prev/'energy_matrix.png')
    for st in ['typing','stretching','cap_adjust','dragging','landing','booped']:
        strip=Image.new('RGBA',(96*8,96),(0,0,0,0))
        for f in range(8):strip.alpha_composite(render(st,f,0),(f*96,0))
        strip.save(prev/(st+'.png'))
    # Actual compact mockup: bird twice native pixel scale, HUD 36px source displayed with same scale.
    for mode,bg in [('light',(246,249,245)),('dark',(34,39,45))]:
        final=Image.new('RGB',(260,275),bg)
        chick=render('typing',2,0).resize((192,192),Image.Resampling.NEAREST)
        final.paste(chick,(34,14),chick)
        hud=Image.open(ROOT/'hud'/'bars.png').resize((72,28),Image.Resampling.NEAREST)
        fill_g=Image.open(ROOT/'hud'/'fill_green.png')
        fill_a=Image.open(ROOT/'hud'/'fill_amber.png')
        dd=ImageDraw.Draw(hud)
        # Fill amounts 78% and 27% in source grid, nearest-neighbor enlarged.
        d1=Image.open(ROOT/'hud'/'bars.png')
        d1.alpha_composite(fill_g.crop((0,0,23,2)),(3,2))
        d1.alpha_composite(fill_a.crop((0,0,8,2)),(3,10))
        hud=d1.resize((72,28),Image.Resampling.NEAREST)
        final.paste(hud,(94,199),hud)
        bubble=Image.open(ROOT/'hud'/'task_bubble.png').resize((40,38),Image.Resampling.NEAREST)
        final.paste(bubble,(183,27),bubble)
        glyph=Image.open(ROOT/'hud'/'digits.png');n=glyph.crop((8,0,11,5)).resize((12,20),Image.Resampling.NEAREST)
        final.paste(n,(197,34),n)
        final.save(prev/('compact_'+mode+'.png'))
    # GIF previews for states and transitions, all 5 tiers, finite and loadable.
    for ti,tname in enumerate(TIERS):
        gd=ROOT/'gifs'/tname;gd.mkdir(parents=True,exist_ok=True)
        sd=ROOT/'strips'/tname;sd.mkdir(parents=True,exist_ok=True)
        for row,key in enumerate(STATES+[x[0] for x in EDGES]):
            ed=next((e for e in EDGES if e[0]==key),None)
            frames=[render(key,k,ti,edge=ed) for k in range(8)]
            st=Image.new('RGBA',(8*96,96),(0,0,0,0))
            for k,fr in enumerate(frames):st.alpha_composite(fr,(k*96,0))
            st.save(sd/(key+'.png'))
            fps=10 if ed else STATE_FPS.get(key,FPS)
            # GIF is a visual preview on a light neutral ground; PNG atlases stay RGBA transparent.
            pal=[]
            for fr in frames:
                base=Image.new('RGB',fr.size,(246,249,245))
                base.paste(fr,(0,0),fr)
                pal.append(base.convert('P',palette=Image.Palette.ADAPTIVE,colors=128))
            pal[0].save(gd/(key+'.gif'),save_all=True,append_images=pal[1:],duration=max(65,int(1000/fps)),loop=0,
                        optimize=False,disposal=2)


def main():
    for name in ('atlas','hud','gifs','strips','icons','previews'):(ROOT/name).mkdir(exist_ok=True)
    entries={}
    for i,s in enumerate(STATES):
        entries[s]={'row':i,'frames':8,'fps':STATE_FPS.get(s,8),'loop':s in LOOP,'tiers':TIERS}
    trans={}
    for i,(key,origin,dest) in enumerate(EDGES):
        trans[key]={'row':30+i,'frames':8,'fps':10,'loop':False,'tiers':TIERS,'from':origin,'to':dest}
    for t,tier in enumerate(TIERS):
        out=sheet(STATES+[x[0] for x in EDGES],t)
        out.save(ROOT/'atlas'/(tier+'.png'),optimize=True)
    hud=make_hud()
    icons(render('idle',1,0))
    mf={'name':'AgentPet','frameSize':{'width':96,'height':96},'columns':8,
        'framesPerAnimation':8,'sourcePixelGrid':[48,48],'scaling':'nearest',
        'character':{'species':'yellow_chick','headwear':'small_white_eggshell_cap',
                     'headphones':False,'workDevice':'mini_laptop','twoWingsOnly':True},
        'tiers':{x:{'range':RANGES[x],'file':'atlas/'+x+'.png','width':768,'height':6528,
                 'animationSpeedMultiplier':{'fresh':1,'focused':0.9,'tired':0.75,'exhausted':0.6,'empty':0.45}[x]}
                 for x in TIERS},
        'states':entries,'transitions':trans,'hud':hud,
        'logic':{'energySource':'remaining_percent_5h','missingUsage':'keep_neutral',
          'runningBubbleOnlyWhenCountPositive':True,
          'idleActivities':['stretching','yawning','coffee_break','looking_around',
                            'tiny_dance','cap_adjust','walking'],
          'idleActivityAfterSeconds':55,'idleActivityIntervalSeconds':[45,125],
          'click':'booped','doubleClick':'giggling','repeatedClick':'annoyed',
          'dragStart':'grabbed','dragging':'dragging','dragEnd':'landing',
          'stop':'ready_not_success','needsInput':'needs_input','running':'typing',
          'energyVariantsForAllAnimations':True}}
    (ROOT/'manifest.json').write_text(json.dumps(mf,indent=2,ensure_ascii=False),encoding='utf-8')
    make_preview()
    print('done',ROOT)

if __name__=='__main__':main()
