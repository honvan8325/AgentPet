#!/usr/bin/env python3
"""Rebuild the Axolotl theme as complete, independent 48px pixel drawings.

All 68 clip rows x 5 energy atlases use the AgentPet Chick clip contract.
Each frame draws a complete axolotl and its pose; there is no cut-and-paste
of detached arms or fixed-body sprite components.
Requires Python 3, Pillow, numpy. This is a development-only tool.
"""
import json
import math
from pathlib import Path
from copy import deepcopy
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
THEME = ROOT/'Themes'/'axolotl'
THEME.mkdir(parents=True,exist_ok=True)
TIERS=['fresh','focused','tired','exhausted','empty']
BASE = ROOT/'manifest_template.json'  # portable; no external workspace dependency
m=json.loads(BASE.read_text())
m['name']='Axolotl'
m['character']={'species':'pink_axolotl','appearance':'round_pink_head_six_external_gills','workDevice':'jump_rope_instead_of_laptop','typingAction':'jump_rope','thinkingAction':'squat','exactlyTwoArmsAndTwoLegs':True}
for tier,d in m['tiers'].items(): d['file']=tier+'.png'
m['hud']['file']='Shared/bars.png'
m['hud']['taskBubble']['file']='Shared/task_bubble.png'
m['hud']['pixelFont']='Shared/digits.png'
m['hud']['positions']={'5H_bar':[2,1,32,4],'7D_bar':[2,6,32,4]}
m['layout']={'bubbleOffset':{'x':-10,'y':7},'hudOffsetY':-6}
idle_map={
    'stretching':['stretch','stretching','stretch_finish'],
    'yawning':['yawn','yawning'],
    'coffee_break':['caffeinate','coffee_break'],
    'looking_around':['look','looking_around'],
    'tiny_dance':['dance','tiny_dance'],
    'cap_adjust':['adjust_cap','cap_adjust'],
    'walking':['walking'],
}
m['logic']['idleActivities']=[{'name':key,'steps':v,**({'holdSecondsRange':[1,2]} if key=='walking' else {})} for key,v in idle_map.items()]
(THEME/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
(ROOT/'manifest_template.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
STATES=m['states']; TRANS=m['transitions']
assert len(STATES)==30 and len(TRANS)==38
assert sorted([x['row'] for x in STATES.values()]+[x['row'] for x in TRANS.values()])==list(range(68))

S=48
C={
 'outline':'#543847', 'outline2':'#805368', 'pink':'#f5afcb', 'pinkTop':'#ffd9e4',
 'pinkLight':'#ffe5ed','pinkShadow':'#d885af','pinkDeep':'#bc628d',
 'blush':'#ed82a9','blushLight':'#ffc7d8','gill':'#f081ab','gillLight':'#ffc2d7',
 'gillDark':'#a95d87','tummy':'#ffdce7','eye':'#483342','shine':'#ffffff',
 'cyan':'#64dfd7','cyanDeep':'#327d94','rope':'#edbc59','ropeDark':'#a26a5b',
 'spark':'#85cfc6', 'sweat':'#83cfe3','orange':'#efa472'
}
DANGER={'failed','interrupted','critical_quota','disconnected'}
REST={'idle','ready','unknown','looking_around','hovering','booped','giggling','annoyed','low_quota','critical_quota','sleeping','yawning','coffee_break','cap_adjust'}

def E(v): return int(round(v))
def ell(d, box, fill, out=None, w=1): d.ellipse(tuple(map(E,box)),fill=fill,outline=out,width=w)
def polygon(d, pts, fill, out=None):
    coords=[tuple(map(E,p)) for p in pts]
    d.polygon(coords,fill=fill)
    if out: d.line(coords+[coords[0]],fill=out,width=1,joint='curve')
def ln(d, coords, fill, w=1): d.line([tuple(map(E,p)) for p in coords],fill=fill,width=w,joint='curve')
def rect(d, coords, fill, outline=None, width=1):
    x0,y0,x1,y1=map(E,coords)
    d.rectangle((min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1)),fill=fill,outline=outline,width=width)

def state_pose(kind, f, fatigue):
    phase=f*math.pi/4
    weight=max(0.20,1-fatigue*0.17)
    bob=([0,0,-1,-1,0,0,1,0][f] if kind not in ['paused','sleeping'] else 0)
    p={'dx':0.,'dy':float(bob),'jump':0.,'squat':0.,'twist':0.,'arms':0.,'handrise':0.,'blink':0.,'mouth':0.,'gill':math.sin(phase)*1.25,'rope':0.,'ropePhase':f, 'rest':0., 'trip':0.}
    if kind=='typing':
        p.update(jump=([0,1,3,4,3,1,0,1][f])*weight, arms=1,rope=1,mouth=1,gill=math.sin(phase)*1.2)
    elif kind=='thinking':
        p.update(squat=([0,1,3,5,5,3,1,0][f])*(0.8 if fatigue>=3 else 1),arms=0.6,mouth=0,gill=math.sin(phase)*1.8)
    elif kind=='syncing':
        p.update(jump=([0,1,2,3,2,1,0,1][f])*weight,arms=.8,twist=math.sin(phase))
    elif kind=='needs_input': p.update(arms=.6,handrise=1.2+math.sin(phase)*.35,blink=f==3,mouth=2)
    elif kind=='ready': p.update(rest=0.2,arms=0,mouth=1,blink=1 if f==4 else 0)
    elif kind=='celebrating':p.update(jump=[1,3,4,2,1,3,4,2][f]*weight,handrise=3,arms=1,mouth=1,gill=math.sin(phase)*2)
    elif kind=='failed':p.update(rest=1.8,dy=2+math.sin(phase)*1.2,trip=2,mouth=3,arms=-1,twist=math.sin(phase)*1.4)
    elif kind=='interrupted':p.update(rest=.8,handrise=.8,mouth=2,gill=-1)
    elif kind=='paused':p.update(rest=.6,blink=1,mouth=0)
    elif kind=='unknown':p.update(rest=.3,mouth=2,gill=math.sin(phase))
    elif kind=='disconnected':p.update(rest=1.,mouth=3,gill=-1.5,blink=f%4==0)
    elif kind=='reconnecting':p.update(twist=math.sin(phase)*1.8,arms=.25,mouth=2)
    elif kind=='sleeping':p.update(dy=4,rest=3.3,blink=1,mouth=0,gill=-2)
    elif kind=='walking':p.update(dx=math.sin(phase)*1.6,jump=max(0,math.sin(phase))*1.2*weight,twist=math.sin(phase)*1.5,arms=.2)
    elif kind=='hovering':p.update(jump=1+max(0,math.sin(phase)),handrise=.8,mouth=1)
    elif kind=='low_quota':p.update(rest=1.2,mouth=3,gill=-1)
    elif kind=='critical_quota':p.update(rest=2.2,mouth=3,gill=-2)
    elif kind=='stretching':p.update(handrise=([.0,.5,1.5,3,3,1.5,.5,0][f]),rest=-.5,mouth=1)
    elif kind=='yawning':p.update(rest=1,blink=1,mouth=4 if f in (2,3,4,5) else 0)
    elif kind=='coffee_break':p.update(handrise=([0,.3,1,1.4,1.4,1,.3,0][f]),mouth=1)
    elif kind=='looking_around':p.update(twist=([-2,-2,-1,0,1,2,2,0][f]),dx=([-1,-1,0,0,0,1,1,0][f]),mouth=0)
    elif kind=='tiny_dance':p.update(dx=([-2,-1,1,2,2,1,-1,-2][f]),jump=[1,3,1,3,1,3,1,2][f]*weight,arms=1.3,handrise=.8,mouth=1)
    elif kind=='cap_adjust':p.update(handrise=([0,.8,1.8,2.5,2.5,1.8,.8,0][f]),arms=.4,gill=math.sin(phase)*1.8)
    elif kind=='booped':p.update(rest=([0,-1,-2,1,2,1,0,0][f]),mouth=2)
    elif kind=='giggling':p.update(twist=math.sin(phase)*1.5,jump=([0,1,2,1,0,1,2,1][f])*weight,mouth=1,blink=f%3!=0)
    elif kind=='annoyed':p.update(rest=.5,twist=math.sin(phase),mouth=3)
    elif kind=='grabbed':p.update(dy=-2+math.sin(phase)*1.4,handrise=2+math.sin(phase)*.2,mouth=2)
    elif kind=='dragging':p.update(dx=math.sin(phase)*2,dy=-3,handrise=1.8,mouth=2)
    elif kind=='landing':p.update(squat=([3,2,1,0,0,1,0,0][f]),jump=0,mouth=1)
    # Live stamina affects complete morphology and kinetics in EVERY state.
    p['fatigue']=fatigue
    return p

def blend(a,b,t):
    ease=t*t*(3-2*t)
    res={}
    for key in a.keys():
        if key=='fatigue':res[key]=a[key]
        elif key=='ropePhase':res[key]=b[key] if ease>.45 else a[key]
        else:res[key]=a[key]*(1-ease)+b[key]*ease
    return res

def rope_arc(d, hand_l,hand_r, phase, before):
    # One physical rope held in two hands; draw back/top arcs behind body,
    # front/bottom arcs above body to make jump rope rotation legible.
    top = phase in (0,1,7)
    if before!=top: return
    lx,ly=hand_l;rx,ry=hand_r
    if top:
        height={0:4,1:7,7:5}[phase]
        coords=[(lx,ly),(8,21),(6,13),(10,height+5),(18,height),(24,height-1),(30,height),(39,height+5),(42,13),(40,22),(rx,ry)]
    elif phase in (2,6):
        yy=29 if phase==2 else 31
        coords=[(lx,ly),(8,31),(9,yy+5),(17,yy+9),(24,yy+10),(32,yy+9),(39,yy+5),(40,31),(rx,ry)]
    else:
        yy={3:42,4:45,5:42}[phase]
        coords=[(lx,ly),(9,34),(10,yy-2),(18,yy),(24,yy+1),(31,yy),(38,yy-2),(40,34),(rx,ry)]
    ln(d,coords,C['ropeDark'],2)
    ln(d,coords,C['rope'],1)

def draw_character(tier,kind,f,pose=None,rope_scale=1.):
    fatigue=TIERS.index(tier)
    p=state_pose(kind,f,fatigue) if pose is None else pose
    # Whole image is redrawn: body, face, six gills, exactly two arms and two feet.
    canvas=Image.new('RGBA',(S,S),(0,0,0,0)); d=ImageDraw.Draw(canvas)
    shadow=C['outline']; pink=C['pink']; body=C['pinkShadow']
    t=int(p['fatigue']);weak=t>=3
    dx=p['dx']; squat=p['squat']; jump=p['jump'];st=p['rest']
    y=E(p['dy'] + squat*.8 - jump + max(0,t-1)*.95 + st*.6)
    x=E(dx); head_shift=E(max(0,t-1)*1.1 + squat*.55 + st*.3)
    head_y=10+y+head_shift
    body_y=27+y+E(squat*.2)
    handrise=p['handrise']
    armspread=p['arms']
    lift=6 if kind=='stretching' else 4.4 if kind=='celebrating' else 3.5
    yl=32+y-E(handrise*lift);yr=32+y-E(handrise*lift)
    if kind=='cap_adjust':yr=32+y-E(handrise*5.0)
    lx=E(14+x-2*armspread-1.1*handrise);rx=E(34+x+2*armspread+1.1*handrise)
    if kind=='cap_adjust' and handrise>1:rx=E(36+x+1.1*handrise)
    if kind=='coffee_break' and handrise>.5:rx=E(31+x)
    if weak: yl+=max(0,t-2);yr+=max(0,t-2)
    # For jump rope, rear arc sits behind silhouette, front arc in foreground.
    rope_phase=int(p['ropePhase'])%8
    work_rope=p['rope']*rope_scale>.5
    if work_rope: rope_arc(d,(lx,yl),(rx,yr),rope_phase,True)
    # Feet, exactly two rear feet under belly. Changing squat changes stance.
    leg_x=E(squat*1.0); feet_y=41+y-E(squat*1.03)
    if kind=='walking':leg_x+=E(math.sin(f*math.pi/4)*1.5)
    ell(d,(12+x-leg_x,feet_y-2,22+x-leg_x,feet_y+3),shadow)
    ell(d,(13+x-leg_x,feet_y-3,22+x-leg_x,feet_y+2),C['pinkDeep'])
    ell(d,(27+x+leg_x,feet_y-2,38+x+leg_x,feet_y+3),shadow)
    ell(d,(27+x+leg_x,feet_y-3,37+x+leg_x,feet_y+2),C['pinkDeep'])
    for ix in (16+x-leg_x,20+x-leg_x,31+x+leg_x,35+x+leg_x):
        rect(d,(ix,feet_y,ix,feet_y+1),C['pinkLight'])
    # Curled tail behind body (not an arm).
    ell(d,(31+x,33+y,43+x,43+y),shadow)
    ell(d,(33+x,34+y,41+x,41+y),C['pinkDeep'])
    ell(d,(35+x,35+y,39+x,38+y),C['pinkLight'])
    # Pear-shaped rounded torso with large pale belly.
    body_sag=E(max(0,t-2)*1.2)
    ell(d,(14+x,25+y+body_sag,35+x,43+y-E(squat*.58)),shadow)
    ell(d,(15+x,25+y+body_sag,34+x,41+y-E(squat*.38)),body)
    ell(d,(17+x,29+y+body_sag,32+x,40+y-E(squat*.3)),C['tummy'])
    ell(d,(18+x,30+y+body_sag,31+x,39+y-E(squat*.25)),C['pinkLight'])
    ln(d,[(21+x,38+y),(27+x,39+y)],C['blushLight'])
    # Neck and head with no detached overlays.
    ell(d,(11+x,head_y,37+x,29+y),shadow)
    ell(d,(12+x,head_y+1,36+x,28+y),pink)
    ell(d,(15+x,head_y+1,32+x,head_y+7),C['pinkTop'])
    ell(d,(17+x,head_y+2,30+x,head_y+4),C['pinkLight'])
    ell(d,(14+x,head_y+10,34+x,26+y),C['pink'])
    # Three continuous gill stalks attached to EACH side of skull.
    # Droop at depleted energy; all three positions remain clearly connected.
    droop=E((0,.75,1.7,3.7,5.2)[t]+p['gill']*1.0)
    for sign in (-1,1):
        edge=13+x if sign==-1 else 35+x
        for j,(yy,reach) in enumerate(((head_y+3,6),(head_y+11,8),(head_y+17,6))):
            out_y=yy+E((j-1)*1.8)+droop
            far=edge+sign*reach
            mid=edge+sign*(reach*.55)
            polygon(d,[(edge,yy-2),(mid,out_y-3),(far,out_y-2),(far+sign*1,out_y+1),
                       (mid,out_y+2),(edge,yy+2)],C['gillDark'],shadow)
            polygon(d,[(edge+sign,yy-1),(mid,out_y-2),(far,out_y-1),
                       (far,out_y),(mid,out_y+1),(edge+sign,yy+1)],C['gill'],None)
            ln(d,[(mid,out_y-2),(far,out_y-1)],C['gillLight'])
            if j==0: rect(d,(mid,out_y-1,mid+sign,out_y),C['cyan'])
    # Give head a cheek rim; jaw/neck seamlessly meet torso.
    ln(d,[(16+x,27+y),(20+x,28+y),(30+x,28+y),(34+x,26+y)],C['pinkDeep'])
    # Exactly two arms, attached at shoulder and ending in two hands.
    left_attach=(16+x,29+y); right_attach=(33+x,29+y)
    poly_l=[(16+x,27+y),(19+x,29+y),(lx+2,yl),(lx,yl+2),(lx-2,yl), (14+x,31+y)]
    poly_r=[(32+x,27+y),(35+x,28+y),(rx+2,yr),(rx,yr+2),(rx-2,yr), (30+x,30+y)]
    polygon(d,poly_l,C['pinkShadow'],shadow)
    polygon(d,poly_r,C['pinkShadow'],shadow)
    ell(d,(lx-2,yl-2,lx+2,yl+2),C['pink'],shadow)
    ell(d,(rx-2,yr-2,rx+2,yr+2),C['pink'],shadow)
    rect(d,(lx-1,yl-1,lx,yl-1),C['pinkLight'])
    rect(d,(rx-1,yr-1,rx,yr-1),C['pinkLight'])
    # Cup from the SAME right hand, not a third limb.
    if kind=='coffee_break':
        rect(d,(rx-2,yr+1,rx+3,yr+5),C['cyanDeep'],shadow)
        rect(d,(rx-1,yr+1,rx+2,yr+4),C['cyan'])
        ln(d,[(rx+1,yr+1),(rx+3,yr-3)],C['pinkLight'])
    # Jump rope handles and foreground rope: tied to the same two hands.
    if work_rope:
        rect(d,(lx-1,yl-1,lx,yl),C['cyanDeep'])
        rect(d,(rx,yr-1,rx+1,yr),C['cyanDeep'])
        rope_arc(d,(lx,yl),(rx,yr),rope_phase,False)
    # FACE, drawn late so gestures never become extra limbs.
    mouth_y=E(24+y+head_shift*.40)
    # pink cheeks
    ell(d,(15+x,mouth_y-4,20+x,mouth_y-1),C['blush'],None)
    ell(d,(28+x,mouth_y-4,33+x,mouth_y-1),C['blush'],None)
    ell(d,(15+x,mouth_y-5,18+x,mouth_y-4),C['blushLight'],None)
    ell(d,(30+x,mouth_y-5,32+x,mouth_y-4),C['blushLight'],None)
    eye_y=E(19+y+head_shift*.45)
    eye_shift=E(p['twist']*.6)
    # Fatigue gets visible bags and hooded eyes everywhere.
    if t>=2:
        ln(d,[(18+x,eye_y+2),(21+x,eye_y+2)],C['pinkDeep'])
        ln(d,[(28+x,eye_y+2),(31+x,eye_y+2)],C['pinkDeep'])
    sleeping=kind in ('sleeping','yawning') or kind=='paused' or (kind in ('idle','ready') and f==3)
    if sleeping or p['blink'] or t==4:
        ln(d,[(18+x,eye_y),(21+x,eye_y)],C['eye'],2)
        ln(d,[(28+x,eye_y),(31+x,eye_y)],C['eye'],2)
    elif kind in ('annoyed','failed'):
        ln(d,[(18+x,eye_y-1),(21+x,eye_y+1)],C['eye'])
        ln(d,[(28+x,eye_y+1),(31+x,eye_y-1)],C['eye'])
    else:
        eye_h=3 if t<=1 else 2 if t==2 else 1
        for ex in (19+x+eye_shift,29+x+eye_shift):
            rect(d,(ex,eye_y,ex+1,eye_y+eye_h),C['eye'])
            if t<=1:rect(d,(ex,eye_y,ex,eye_y),C['shine'])
    # tiny nostril pair in every mode
    rect(d,(23+x,22+y,23+x,22+y),C['outline2'])
    rect(d,(26+x,22+y,26+x,22+y),C['outline2'])
    if kind=='yawning' and f in (2,3,4,5):ell(d,(23+x,24+y,26+x,27+y),C['outline'])
    elif p['mouth']==3 or t>=4:
        ln(d,[(23+x,mouth_y+2),(25+x,mouth_y+1),(27+x,mouth_y+2)],C['eye'])
    elif p['mouth']==2:
        ell(d,(24+x,mouth_y,25+x,mouth_y+2),C['eye'])
    elif p['mouth']==1:
        ln(d,[(23+x,mouth_y),(24+x,mouth_y+1),(26+x,mouth_y+1),(27+x,mouth_y)],C['eye'])
    else:
        ln(d,[(23+x,mouth_y),(25+x,mouth_y+1),(27+x,mouth_y)],C['eye'])
    if t>=3 and f%4 in (1,2) and kind!='paused':
        rect(d,(36+x,24+y,37+x,27+y),C['sweat'])
        rect(d,(36+x,28+y,36+x,28+y),C['shine'])
    if t==4:ln(d,[(19+x,17+y),(21+x,16+y)],C['pinkDeep'])
    # State-specific effects, with no extra arms or legs.
    if kind=='needs_input':
        rect(d,(40,10,41,15),C['orange'])
        rect(d,(40,17,41,18),C['orange'])
    elif kind=='unknown':
        ln(d,[(39,11),(42,10),(43,12),(41,14),(41,16)],C['cyanDeep'])
        rect(d,(41,18,41,19),C['cyanDeep'])
    elif kind in ('failed','disconnected'):
        ln(d,[(40,9),(45,14)],C['blush'])
        ln(d,[(45,9),(40,14)],C['blush'])
    elif kind=='reconnecting' or kind=='syncing':
        for i in range(3):
            ox=39+((f+i)%3)*2
            rect(d,(ox,8+i*3,ox+1,9+i*3),C['cyan'])
    elif kind in ('ready','celebrating','tiny_dance'):
        ln(d,[(40,13),(42,15),(45,10)],C['cyan'])
    elif kind=='sleeping':
        for i in range(2):
            xx=39+i*4;yy=14-i*5-f//3
            ln(d,[(xx,yy+3),(xx+3,yy+3),(xx,yy+1),(xx+3,yy+1)],C['cyanDeep'])
    elif kind in ('hovering','giggling','booped'):
        for xx,yy in ((9,10),(40,8)):
            ln(d,[(xx,yy-2),(xx,yy+2)],C['spark'])
            ln(d,[(xx-2,yy),(xx+2,yy)],C['spark'])
    elif kind=='annoyed':
        ln(d,[(17+x,16+y),(21+x,17+y)],C['eye'])
        ln(d,[(28+x,17+y),(32+x,16+y)],C['eye'])
    elif kind=='cap_adjust' and handrise>1:
        rect(d,(37+x,head_y+8,39+x,head_y+9),C['spark'])
    elif kind=='paused':
        rect(d,(40,10,41,15),C['cyanDeep'])
        rect(d,(44,10,45,15),C['cyanDeep'])
    elif kind in ('critical_quota','low_quota'):
        rect(d,(39,11,40,14),C['orange'])
        rect(d,(39,16,40,16),C['orange'])
    # Strength-level tiny decorative glints only when energized
    if t<2 and kind in ('typing','celebrating','tiny_dance') and f in (2,5):
        rect(d,(6,9,7,9),C['spark'])
        rect(d,(6,7,6,11),C['spark'])
    # Keep full RGBA authored in this render, never overlay a pasted limb image.
    return canvas

def render(tier,key,f):
    if key in STATES:
        return draw_character(tier,key,0 if key=='paused' else f)
    clip=TRANS[key]
    a=clip['from'];b=clip['to']
    x=f/7
    prev=state_pose(a,f,TIERS.index(tier));nxt=state_pose(b,f,TIERS.index(tier))
    combo=blend(prev,nxt,x)
    # Render transition poses continuously, including lift/squat/arms, not sudden A/B strips.
    # The last two frames take destination's visual action for continuity.
    dominant=b if x>.52 else a
    if x>=.75: combo['rope']=nxt['rope'];combo['ropePhase']=nxt['ropePhase']
    return draw_character(tier,dominant,f,combo)

if __name__=='__main__':
    clips=[*STATES.items(),*TRANS.items()]
    # Generate each tier atlas and strip from the same final RGBA frame pixels.
    for tier in TIERS:
        atlas=Image.new('RGBA',(768,6528),(0,0,0,0))
        sd=ROOT/'strips'/tier; gd=ROOT/'gifs'/tier
        sd.mkdir(parents=True,exist_ok=True);gd.mkdir(parents=True,exist_ok=True)
        for key,info in clips:
            frames=[render(tier,key,j).resize((96,96),Image.Resampling.NEAREST) for j in range(8)]
            strip=Image.new('RGBA',(768,96),(0,0,0,0))
            for j,frame in enumerate(frames):
                strip.alpha_composite(frame,(j*96,0))
                atlas.alpha_composite(frame,(j*96,info['row']*96))
            strip.save(sd/(key+'.png'),optimize=True)
            if key=='paused':
                frames=[frames[0] for _ in range(8)]
            frames[0].save(gd/(key+'.gif'),save_all=True,append_images=frames[1:],duration=max(70,round(1000/info['fps'])),loop=0,disposal=2,optimize=True)
        atlas.save(THEME/(tier+'.png'),optimize=True)
    sprite=render('fresh','idle',1).resize((96,96),Image.Resampling.NEAREST)
    sprite.save(THEME/'preview.png',optimize=True)
    (ROOT/'preview.png').write_bytes((THEME/'preview.png').read_bytes())
    # Colored preview boards: no custom proprietary fonts or UI coupling.
    def checker(w,h):
        ar=np.empty((h,w,3),dtype=np.uint8)
        for y in range(h):
            for x in range(w):
                ar[y,x]=[252,248,250] if ((x//16+y//16)%2)==0 else [245,233,241]
        return Image.fromarray(ar,'RGB').convert('RGBA')
    overview=checker(680,420)
    d=ImageDraw.Draw(overview)
    big=sprite.resize((288,288),Image.Resampling.NEAREST)
    overview.alpha_composite(big,(20,66))
    d.text((32,26),'AXOLOTL  /  AgentPet Theme',fill=C['outline'])
    poses=[('fresh','typing'),('fresh','thinking'),('tired','idle'),('exhausted','typing'),('fresh','stretching'),('empty','sleeping')]
    for i,(tier,key) in enumerate(poses):
        xp=340+(i%3)*110;yp=60+(i//3)*176
        overview.alpha_composite(render(tier,key,3).resize((104,104),Image.Resampling.NEAREST),(xp,yp))
        d.text((xp,yp+108),key,fill=C['outline'])
        d.text((xp,yp+123),tier,fill=C['outline2'])
    overview.convert('RGB').save(ROOT/'showcase.png',optimize=True)
    energy=checker(700,184)
    d=ImageDraw.Draw(energy)
    for i,tier in enumerate(TIERS):
        xx=i*140+18
        image=render(tier,'idle',1).resize((124,124),Image.Resampling.NEAREST)
        energy.alpha_composite(image,(xx,12))
        d.text((xx+8,146),tier.upper(),fill=C['outline'])
    energy.convert('RGB').save(ROOT/'energy.png',optimize=True)
    contact=checker(6*124,5*137)
    dd=ImageDraw.Draw(contact)
    for i,key in enumerate(STATES):
        xx=(i%6)*124+10; yy=(i//6)*137+2
        contact.alpha_composite(render('fresh',key,2).resize((96,96),Image.Resampling.NEAREST),(xx,yy))
        dd.text((xx,yy+99),key,fill=C['outline'])
    contact.convert('RGB').save(ROOT/'states.png',optimize=True)
    for key in ['idle','typing','thinking','needs_input','stretching','cap_adjust','dragging','landing','sleeping']:
        images=[render('fresh',key,j).resize((96,96),Image.Resampling.NEAREST) for j in range(8)]
        strip=checker(800,120);dt=ImageDraw.Draw(strip)
        for j,im in enumerate(images): strip.alpha_composite(im,(j*100+4,4))
        strip.convert('RGB').save(ROOT/'previews'/(key+'.png'),optimize=True)
        images[0].save(ROOT/'previews'/(key+'.gif'),save_all=True,append_images=images[1:],duration=max(70,round(1000/STATES[key]['fps'])),loop=0,disposal=2,optimize=True)
    (ROOT/'README.txt').write_text(
        'Axolotl pixel mascot for AgentPet. 30 states, 38 transitions, five energy atlases.\n'
        'Install only Themes/axolotl in AgentPet/Resources/Themes and register case axolotl in PetTheme.\n'
        'Clip names and row numbers are intentionally IDENTICAL to Chick: typing=jump rope, thinking=squats, cap_adjust=gill adjustment.\n'
        'Requires Shared/bars.png, Shared/digits.png, Shared/task_bubble.png and Shared/fill_*.png from AgentPet.\n'
        'All 96x96 animation frames drawn as complete character renders in Python/Pillow + NumPy; no ChatGPT image generation used.\n'
        'Source: generate_assets.py. GIF and strip previews are only for development, not bundled into .app.\n',encoding='utf8')
    print(f'Generated {len(STATES)} states, {len(TRANS)} transitions, {len(TIERS)} tiers, {len(clips)*8*len(TIERS)} frames.')
