Axolotl pixel mascot for AgentPet. 30 states, 38 transitions, five energy atlases.
Install only Themes/axolotl in AgentPet/Resources/Themes and register case axolotl in PetTheme.
Clip names and row numbers are intentionally IDENTICAL to Chick: typing=jump rope, thinking=squats, cap_adjust=gill adjustment.
Requires Shared/bars.png, Shared/digits.png, Shared/task_bubble.png and Shared/fill_*.png from AgentPet.
All 96x96 animation frames drawn as complete character renders in Python/Pillow + NumPy; no ChatGPT image generation used.
Source: generate_assets.py. GIF and strip previews are only for development, not bundled into .app.
