Coder: pixel chibi based on the provided photo.
Copy Themes/coder into AgentPet/Resources/Themes/coder, add case coder to PetTheme, build.
Uses common Shared HUD and bubble assets. No Swift or Codex behavior changes.
Source frames are independently redrawn; 30 states + 38 transitions, 5 energy atlas PNGs.
